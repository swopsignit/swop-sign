# swop-sign — tekenrepo voor Swop-releases

Deze map is de inhoud van de repo `swop-sign` onder het aparte GitHub-account **Swop Sign**. Die repo tekent
releases (plugins, thema's, de Bridge) die Swop Hub op sites zet. De Bridge plaatst in de stand "verplicht" alleen
getekende releases. Zo kan ook een overgenomen Swop Hub, een gelekt sitegeheim of een gemanipuleerde Claude-sessie
geen eigen code op klantsites krijgen.

## Waarom een apart account

Claude-sessies werken op GitHub als Swoptastic, met eigenaarsrechten. Stond de sleutel daar, dan kon een
gemanipuleerde sessie de verplichte goedkeuring weghalen. Daarom:

- Swop Sign logt alleen in met een beveiligingssleutel of passkey en wordt nooit gekoppeld aan Claude, Lovable of het
  Chrome-profiel dat Claude bestuurt.
- Swoptastic heeft geen toegang tot deze repo (alleen tijdelijk bij het neerzetten van de bestanden).
- Swop Hub start rondes met een token dat alleen "Actions: Read and write" heeft. Goedkeuren vraagt "Deployments" en
  de reviewer zelf; dat kan Swop Hub dus niet.

## Hoe een ronde loopt

1. Swop Hub start `Tekenen` met: soort, slug, versie, sha256, commit, bronmap en een downloadlink van 5 minuten.
2. Job **controleren** (zonder sleutel): haalt de zip, controleert de sha256, controleert dat de commit op main staat
   en vergelijkt elk bestand in de zip met de bron op die commit (`scripts/vergelijk.py`). In de samenvatting staat
   wat er sinds de vorige getekende versie veranderd is.
3. Job **tekenen** wacht op akkoord (omgeving `tekenen`). Na Approve tekent `scripts/teken.php`, wordt
   `getekend/<soort>/<slug>/<versie>.json` vastgelegd en gaat de handtekening naar Swop Hub.
4. Afgekeurd of afgewezen: Swop Hub krijgt de reden en de release blijft ongetekend.

## Inrichting (eenmalig)

1. Omgeving `tekenen` (Settings → Environments): Required reviewers = Swop Sign; "Prevent self-review" uit (Swop Hub
   start de rondes met een token van Swop Sign zelf); Deployment branches = alleen `main`.
2. Repo-variabelen (Settings → Secrets and variables → Actions → Variables):
   - `SOURCE_REPO` = `Swoptastic/swop-site-plugins`
   - `HUB_SIGN_URL` = `https://jyphtsuxvkdhmjtsxxgx.supabase.co/functions/v1/release-sign`
   - `ZIP_PREFIX` = `https://jyphtsuxvkdhmjtsxxgx.supabase.co/storage/v1/object/sign/`
3. Repo-geheim `SOURCE_TOKEN`: fine-grained token van **Swoptastic**, alleen repo swop-site-plugins,
   "Contents: Read-only". Alleen lezen van de bron.
4. Sleutel: maak als Swop Sign een fine-grained token, alleen deze repo, "Environments: Read and write", zet het als
   repo-geheim `SLEUTEL_TOKEN`, draai Actions → Sleutel maken (keur goed), en verwijder daarna het geheim én het token.
   Het key-id en de publieke sleutel uit de samenvatting gaan in de Bridge en in Swop Hub. Die zijn niet geheim.
5. Token voor Swop Hub: fine-grained token van Swop Sign, alleen deze repo, alleen "Actions: Read and write", geldig
   1 jaar. Dit zet Roy zelf als geheim `SWOP_SIGN_DISPATCH_TOKEN` in Swop Hub (nooit in een chat).

## Sleutel wisselen of kwijt

- Kwijt of gelekt: Sleutel maken met vervangen = ja, nieuwe publieke sleutel in een nieuwe Bridge-versie, uitrollen,
  oude sleutel uit de Bridge halen. Sites in "verplicht" accepteren tot die update alleen de oude sleutel; zet ze zo
  nodig in wp-admin even terug op "meten".
- Dit account kwijt: draaiende sites merken niets. Alleen nieuwe plaatsingen staan stil; handmatig uploaden in
  wp-admin blijft werken.
